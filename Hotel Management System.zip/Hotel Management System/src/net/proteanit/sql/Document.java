package src.net.proteanit.sql;

import jdk.javadoc.internal.doclets.formats.html.markup.Head;

import javax.swing.text.Element;

public class Document {
    public Document(Element element) {

    }

    public Head getRootElement() {
    }
}
